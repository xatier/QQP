#include <iostream>
using namespace std;




int main()
{
	int a[15]={4,5,2,5,4,3,5,4,1,3,3,5,5,4,2};
	heapsort(a,a+15,less<int>());
	for (int i=0;i<15;i++) cout << a[i] << ' '; cout << endl;

	char b[20]="snoopyplutogarfield";
	heapsort(b,b+19,greater<char>());
	for (int i=0;i<19;i++) cout << b[i] << ' '; cout << endl;

	char* c[11]={"Yankees","Indians","Cubs","Astros","Dodgers","Mets","Twins","Royals","Giants","Braves","Orioles"};
	heapsort(c,c+11,less<const char*>());
	for (int i=0;i<11;i++) cout << c[i] << ' '; cout << endl;

	heapsort(c,c+11,greater<const char*>());
	for (int i=0;i<11;i++) cout << c[i] << ' '; cout << endl;
}