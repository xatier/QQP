#include <iostream> 
#include <forward_list>
#include <list>
#include <vector>
using namespace std;

template<typename InputIterator, class Predicate>
bool gogo(InputIterator& first, InputIterator& last, Predicate pr, forward_iterator_tag) {
    for (InputIterator& it = first; it != last; ++it) {
        if (pr(*it))
            return 1;
    }
    return 0;
}

template<typename InputIterator, class Predicate>
bool gogo(InputIterator& first, InputIterator& last, bidirectional_iterator_tag, Predicate pr) {
    for (InputIterator& it = last; it != first; --it) {
        if (pr(*it))
            return 1;
    }
    return 0;
}

template<typename InputIterator, class Predicate>
bool gogo(InputIterator& first, InputIterator& last, random_access_iterator_tag, Predicate pr) {
    if (first == last)
        if (pr(*first))
            return 1;
        else
            return 0;
    int n = (last - first) / 2;
    gogo(first, first + n);
    gogo(first+n+1, last);
}

template<class InputIterator, class Predicate>
bool any_of(InputIterator first,InputIterator last, Predicate pr) {
    return gogo(first, last, pr, typename iterator_traits<InputIterator>::iterator_category());
}


int main()
{   
    int a[9]={1,2,3,4,5,6,7,8,9};
    forward_list<int> xs(begin(a),end(a));
    cout << any_of(begin(xs),begin(xs),[](int x) { return x==3; });
    cout << any_of(xs.begin(),xs.end(),[](int x) { return x==4; });
    list<int> ys(begin(a),end(a));
    cout << any_of(ys.begin(),ys.end(),[](int x) { return x==5; });
    vector<int> zs(begin(a),end(a));
    cout << any_of(zs.begin(),zs.end(),[](int x) { return x==6; });
    string s("Snoopy");
    cout << any_of(s.begin(),s.end(),[](char c) { return c=='c'; });
}

